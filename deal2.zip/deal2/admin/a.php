<?php
// Establish database connection
require_once 'conn.php';

// Execute the SQL query
$query = "SELECT numbers.luck_number, COALESCE(SUM(total_payout), 0) AS total FROM 
( SELECT 0 AS luck_number UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 
UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL
 SELECT 8 UNION ALL SELECT 9 ) AS numbers LEFT JOIN ( SELECT luck_number, SUM(amount_placed * 3.5) 
 AS total_payout FROM betting WHERE status = 'pending' GROUP BY luck_number UNION ALL SELECT luck_number,
  SUM( CASE WHEN luck_number % 2 = 0 THEN amount_placed * 1.2 ELSE amount_placed END ) AS total_payout
   FROM betting WHERE status = 'pending' GROUP BY luck_number ) AS combined_results ON numbers.luck_number
    = combined_results.luck_number GROUP BY numbers.luck_number ORDER BY `total` ASC;;";
$result = $conn->query($query);

// Fetch the results into an array
$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Find the number(s) with the minimum total payout
$minimumTotal = PHP_INT_MAX;
$minimumTotalNumbers = array();
foreach ($data as $row) {
    if ($row['total'] < $minimumTotal) {
        $minimumTotal = $row['total'];
        $minimumTotalNumbers = array($row['luck_number']);
    } elseif ($row['total'] == $minimumTotal) {
        $minimumTotalNumbers[] = $row['luck_number'];
    }
}

// Choose the lucky number based on the criteria
if (count($minimumTotalNumbers) == 1) {
    $luckyNumber = $minimumTotalNumbers[0];
} else {
    if ($minimumTotal == 0) {
        // Randomly choose a number if there are multiple numbers with zero total payout
        $luckyNumber = $minimumTotalNumbers[array_rand($minimumTotalNumbers)];
    } else {
        // If there are multiple numbers with non-zero minimum total payout, choose the first one
        $luckyNumber = $minimumTotalNumbers[0];
    }
}

function generate_numbers($n)
{
    if ($n >= 0 && $n <= 9) {
        $numbers = [];
        if ($n >= 0 && $n <= 4) { // if the chosen number is in the small range
            if ($n % 2 == 0) { // if the chosen number is even
                for ($i = 0; $i <= 4; $i += 2) {
                    if ($i != $n) {
                        $numbers[] = $i;
                    }
                }
            } else { // if the chosen number is odd
                for ($i = 1; $i <= 3; $i += 2) {
                    if ($i != $n) {
                        $numbers[] = $i;
                    }
                }
            }
        } elseif ($n >= 5 && $n <= 9) { // if the chosen number is in the big range
            if ($n % 2 == 0) { // if the chosen number is even
                for ($i = 6; $i <= 8; $i += 2) {
                    if ($i != $n) {
                        $numbers[] = $i;
                    }
                }
            } else { // if the chosen number is odd
                for ($i = 5; $i <= 9; $i += 2) {
                    if ($i != $n) {
                        $numbers[] = $i;
                    }
                }
            }
        }
        return $numbers;
    } else {
        return "Invalid number. Please choose a number between 0 and 9.";
    }
}

if ($luckyNumber !== null) {
    $result1 = generate_numbers($luckyNumber);
    $v = implode(" , ", $result1);
   // echo $v. '  '.$luckyNumber;

}

function insertBettingRecords($conn, $numRecords = 30) {
    $draw_id_query = "SELECT CONCAT('DR', LPAD(SUBSTRING(draw_id, 3) + 1, 5, '0')) AS new_draw_id FROM draws ORDER BY draw_id DESC LIMIT 1";
    $new_draw_id = $conn->query($draw_id_query)->fetch_assoc()['new_draw_id'] ?? 'DR00001';
    $sql = "INSERT INTO `betting` (`user_id`, `luck_number`, `amount_placed`, `time`, `status`, `draw_id`) VALUES ";
    $values = [];

    for ($i = 0; $i < $numRecords; $i++) {
        $userId = rand(11, 19);
        $luckNumber = rand(0, 9);
        $amountPlaced = rand(10, 20);
        $time = date('Y-m-d H:i:s');
        $status = 'pending';
        $values[] = "($userId, $luckNumber, $amountPlaced, '$time', '$status', '$new_draw_id')";
    }

    $sql .= implode(", ", $values);

    $conn->query($sql);
}
insertBettingRecords($conn, 30); 
?>