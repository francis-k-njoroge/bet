<?php
include "conn.php";
ob_start();
require_once 'a.php'; // Assuming 'a.php' contains your function definitions
ob_end_clean();
$v = implode(" , ", $result1);
$luckyNumber = $luckyNumber;

$query_total = "SELECT SUM(amount_placed) AS total_amount_placed FROM betting WHERE status = 'pending'";
$result_total = $conn->query($query_total);
$total_amount_placed = $result_total->fetch_assoc()['total_amount_placed'] ?? 0;

$query_gold="SELECT sum(`amount_placed`*3.5) as golds FROM `betting` WHERE`status`='pending' AND `luck_number`=$luckyNumber;";
$result_gold = $conn->query($query_gold);
$total_gold = $result_gold->fetch_assoc()['golds'] ?? 0;

$query_silver="SELECT sum(`amount_placed`*1.1) as silver FROM `betting` WHERE`status`='pending' AND `luck_number`IN ($v);";
$result_silver = $conn->query($query_silver);
$total_silver = $result_silver->fetch_assoc()['silver'] ?? 0;

$profit =$total_amount_placed-  $total_gold- $total_silver ;

$insert_draws_query = "INSERT INTO `draws`(`lucky_number`, `date`, `amount_placed`, `Profit`) VALUES ('$luckyNumber', NOW(), '$total_amount_placed', '$profit')";
$conn->query($insert_draws_query);
?>
