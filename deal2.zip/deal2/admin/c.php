<?php 
include 'conn.php';
ob_start();
require_once 'b.php';
ob_end_clean();

$v = implode(",", $result1); // Convert the array to a comma-separated string
$luckyNumber = $luckyNumber; // Fetch users who guessed the lucky number

$query_goldwinners = "SELECT a.`user_id`, a.`amount`, b.`luck_number`, b.`amount_placed`,b.`winloss`,SUM(b.`amount_placed` * 3.5) AS total 
                     FROM `accounts` a 
                     JOIN `betting` b ON a.`user_id` = b.`user_id`
                     WHERE b.`luck_number` = ? and `winloss`='notproccess' AND `status`='pending'
                     GROUP BY a.`user_id`, a.`amount`, b.`luck_number`, b.`amount_placed`;";

$stmt_goldwinners = $conn->prepare($query_goldwinners);
$stmt_goldwinners->bind_param("s", $luckyNumber); // Bind the parameter
$stmt_goldwinners->execute();
$result_goldwinners = $stmt_goldwinners->get_result();

if ($result_goldwinners->num_rows > 0) {
   while ($row = $result_goldwinners->fetch_assoc()) {
       $user_id = $row['user_id'];
       $new_balance = $row['total'] + $row['amount'];
       
       // Update the user's balance
       $update_goldwinners_balance = "UPDATE `accounts` SET `amount` = '$new_balance' WHERE `user_id` = '$user_id'";
       $conn->query($update_goldwinners_balance);
       
       $update_betting = "UPDATE `betting` SET `status`='Process', `winloss`='Goldwin' WHERE `luck_number`=$luckyNumber";
       $conn->query($update_betting);
   }
}

// Fetch users who guessed the lucky number for silver winners
$query_silverwinner = "SELECT a.`user_id`, a.`amount`, b.`luck_number`, b.`amount_placed`, b.`status`, SUM(b.`amount_placed` * 1.1) AS total
                      FROM `accounts` a
                      JOIN `betting` b ON a.`user_id` = b.`user_id`
                      WHERE b.`status` = 'pending' AND `winloss`='notproccess' AND b.`luck_number` IN (?)
                      GROUP BY a.`user_id`, a.`amount`, b.`luck_number`, b.`amount_placed`, b.`status`;";

$stmt_silverwinner = $conn->prepare($query_silverwinner);
$stmt_silverwinner->bind_param("s", $v); // Bind the parameter
$stmt_silverwinner->execute();
$result_silverwinner = $stmt_silverwinner->get_result();

if ($result_silverwinner->num_rows > 0) {
   while ($row = $result_silverwinner->fetch_assoc()) {
       $user_id = $row['user_id'];
       $new_balance = $row['total'] + $row['amount'];
       
       // Update the user's balance
       $update_silverwinner_balance = "UPDATE `accounts` SET `amount` = '$new_balance' WHERE `user_id` = '$user_id'";
       $conn->query($update_silverwinner_balance);
       
       $update_betting = "UPDATE `betting` SET `status`='Process', `winloss`='Silver' WHERE `luck_number` IN ($v)";
       $conn->query($update_betting);
   }
}

$update_all = "UPDATE `betting` SET `status` = 'Process', `winloss` = 'loss' WHERE `winloss` NOT IN ('Goldwin', 'Silver')";
$conn->query($update_all);
?>