
<div>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <div class="container-fluid pt-4 px-4">
             <div class="row g-4">
                 <div class="col-sm-6 col-xl-8">
                 <canvas id="luckyNumberChart"></canvas>
                  </div>
              </div>
           </div>


    <script>
        // Connect to the database and fetch the data
        <?php
        require_once 'conn.php';

        $sql = "SELECT `draw_id`, `lucky_number`, `date` FROM `draws`";
        $result = $conn->query($sql);

        $data = array();
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        ?>

        // Prepare the data for Chart.js
        var labels = [];
        var luckyNumbers = [];

        <?php foreach ($data as $row): ?>
        labels.push('<?php echo $row['date']; ?>');
        luckyNumbers.push(<?php echo $row['lucky_number']; ?>);
        <?php endforeach; ?>

        var ctx = document.getElementById('luckyNumberChart').getContext('2d');
        var luckyNumberChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Lucky Number',
                        data: luckyNumbers,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                        pointRadius: 5,
                        pointBackgroundColor: function(context) {
                            var index = context.dataIndex;
                            return (luckyNumbers[index] % 2 === 0) ? 'green' : 'red';
                        }
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</div>
