<?php
include "conn.php";

function insertBettingRecords($conn, $numRecords = 30) {
    $sql = "INSERT INTO `betting` (`user_id`, `luck_number`, `amount_placed`, `time`, `status`) VALUES ";
    $values = [];

    for ($i = 0; $i < $numRecords; $i++) {
        $userId = rand(11, 19);
        $luckNumber = rand(0, 9);
        $amountPlaced = rand(10, 20);
        $time = date('Y-m-d H:i:s');
        $status = 'pending';

        $values[] = "($userId, $luckNumber, $amountPlaced, '$time', '$status')";
    }

    $sql .= implode(", ", $values);

    $conn->query($sql);
       
}
insertBettingRecords($conn, 30); 
$conn->close();
?>