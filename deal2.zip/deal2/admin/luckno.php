<?php
// Establish database connection
require_once 'conn.php';

// Execute the SQL query
$query = "SELECT numbers.luck_number, COALESCE(SUM(total_payout), 0) AS total FROM 
( SELECT 0 AS luck_number UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL 
 SELECT 8 UNION ALL SELECT 9 ) AS numbers LEFT JOIN ( SELECT luck_number, SUM(amount_placed * 3.5)
  AS total_payout FROM betting GROUP BY luck_number UNION ALL SELECT luck_number, 
  SUM(CASE WHEN luck_number % 2 = 0 THEN amount_placed * 1.2 ELSE amount_placed END) 
  AS total_payout FROM betting GROUP BY luck_number ) AS combined_results
   ON numbers.luck_number = combined_results.luck_number GROUP BY numbers.luck_number
    ORDER BY `total` ASC;";
$result = $conn->query($query);

// Fetch the results into an array
$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

// Find the number(s) with the minimum total payout
$minimumTotal = PHP_INT_MAX;
$minimumTotalNumbers = array();
foreach ($data as $row) {
    if ($row['total'] < $minimumTotal) {
        $minimumTotal = $row['total'];
        $minimumTotalNumbers = array($row['luck_number']);
    } elseif ($row['total'] == $minimumTotal) {
        $minimumTotalNumbers[] = $row['luck_number'];
    }
}

// Choose the lucky number based on the criteria
if (count($minimumTotalNumbers) == 1) {
    $luckyNumber = $minimumTotalNumbers[0];
} else {
    if ($minimumTotal == 0) {
        // Randomly choose a number if there are multiple numbers with zero total payout
        $luckyNumber = $minimumTotalNumbers[array_rand($minimumTotalNumbers)];
    } else {
        // If there are multiple numbers with non-zero minimum total payout, choose the first one
        $luckyNumber = $minimumTotalNumbers[0];
    }
}

//$luckyNumber;
function generate_numbers($n)
{
    if ($n >= 0 && $n <= 9) {
        $numbers = [];
        if ($n >= 0 && $n <= 4) { // if the chosen number is in the small range
            if ($n % 2 == 0) { // if the chosen number is even
                for ($i = 0; $i <= 4; $i += 2) {
                    if ($i != $n) {
                        $numbers[] = $i;
                    }
                }
            } else { // if the chosen number is odd
                for ($i = 1; $i <= 3; $i += 2) {
                    if ($i != $n) {
                        $numbers[] = $i;
                    }
                }
            }
        } elseif ($n >= 5 && $n <= 9) { // if the chosen number is in the big range
            if ($n % 2 == 0) { // if the chosen number is even
                for ($i = 6; $i <= 8; $i += 2) {
                    if ($i != $n) {
                        $numbers[] = $i;
                    }
                }
            } else { // if the chosen number is odd
                for ($i = 5; $i <= 9; $i += 2) {
                    if ($i != $n) {
                        $numbers[] = $i;
                    }
                }
            }
        }
        return $numbers;
    } else {
        return "Invalid number. Please choose a number between 0 and 9.";
    }
}

if ($luckyNumber !== null) {
    $result1 = generate_numbers($luckyNumber);
    $v = implode(" , ", $result1);

    echo "$luckyNumber";
    
}

?>


  <div class=" rounded h-100 p-4">
    <h2>Gold winner </h2>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Betting ID</th>
          <th>User ID</th>
          <th>Luck Number</th>
          <th>Amount Placed</th>
          <th>Win</th>
          <th>Time</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <?php
          // Database connection
          

          $sum_gold= 0; 
        $sql = "SELECT `betting_id`, `user_id`, `luck_number`,  `amount_placed`, `time`, `status` FROM `betting` WHERE `luck_number`= '$luckyNumber'";
          $result = $conn->query($sql);

          if ($result->num_rows > 0) {
              // Output data of each row
              while($row = $result->fetch_assoc()) {
                $gold = $row["amount_placed"] * 1.2;
                $sum_gold += $gold;
                  echo
                  
                  "<tr>
                          <td>" . $row["betting_id"] . "</td>
                          <td>" . $row["user_id"] . "</td>
                          <td>" . $row["luck_number"] . "</td>
                          <td>" . $row["amount_placed"] . "</td>
                          <td>".($row["amount_placed"] * 3.5)."</td>
                          <td>" . $row["time"] . "</td>
                          <td>" . $row["status"] . "</td>
                        </tr>";
              }
          } else {
              echo "<tr><td colspan='8'>No results found</td></tr>";
          }
         
        ?>
         <?php  echo  "<tr><td colspan='8'> TOTAL= $sum_gold </td></tr>"; ?>
      </tbody>
    </table>
  </div>

  <div class="bg-light rounded h-100 p-4">
        <h2>Silver</h2>
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Betting ID</th>
                    <th>User ID</th>
                    <th>Luck Number</th>
                    <th>Amount Placed</th>
                    <th>Amount Placed</th>
                    <th>Time</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total_sum = 0; 

                
                $sql = "SELECT `betting_id`, `user_id`, `luck_number`, `amount_placed`, `time`, `status` FROM `betting` WHERE `luck_number` IN ($v)";
                $result = $conn->query($sql);

                // Display records
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $multiplied_value = $row["amount_placed"] * 1.2;
                        $total_sum += $multiplied_value;

                        echo "<tr>";
                        echo "<td>".$row["betting_id"]."</td>";
                        echo "<td>".$row["user_id"]."</td>";
                        echo "<td>".$row["luck_number"]."</td>";
                        echo "<td>".$row["amount_placed"]."</td>";
                        echo "<td>".($row["amount_placed"] * 1.1)."</td>";
                        echo "<td>".$row["time"]."</td>";
                        echo "<td>".$row["status"]."</td>";
                        echo "</tr>";
                       
                    }
                } else {
                    echo "<tr><td colspan='8'>No records found</td></tr>";
                }

                // Close connection
               // $conn->close();
                ?>
               <?php  echo  "<tr><td colspan='8'> TOTAL= $total_sum </td></tr>"; ?>
            </tbody>
        </table>
    </div>

 

