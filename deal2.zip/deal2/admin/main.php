<?php
// Execute a.php
require_once 'a.php';

// Execute b.php
require_once 'b.php';

// Execute c.php
require_once 'c.php';
?>
