<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location:../register");
    exit;
}
$user_id = $_SESSION['user_id'];
$session_duration = 300; // 5 minutes in seconds
$_SESSION['expire_time'] = time() + $session_duration;

include 'conn.php';
$stmt = $conn->prepare("SELECT `user_id`, `username`, `first_name`, `last_name`, `user_email`, `phone_number` FROM `users` WHERE  `user_id` = ?");
$stmt->bind_param("s", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    $user_id = $row['user_id'];
    $user_name = $row['username'];
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $user_email = $row['user_email'];
    $phone_number = $row['phone_number'];
} else {
   
    header("location:../register");
    exit();
}
$query = "SELECT `account_id`, `amount`, `deposit_id`, `date_of_deposit` FROM `accounts` WHERE `user_id` = $user_id";
    $result = mysqli_query($conn, $query);

    // Check if query was successful
    if ($result) {
        // Fetch data and display in HTML template
        while ($row = mysqli_fetch_assoc($result)) {
            $account_id = $row['account_id'];
            $amount = $row['amount'];
            $deposit_id = $row['deposit_id'];
            $date_of_deposit = $row['date_of_deposit'];
        }
      }
$total="SELECT SUM( `amount`)AS balance FROM `accounts` WHERE `user_id`= $user_id;";
$result= mysqli_query($conn,$total);

if($result){
    while($row=mysqli_fetch_assoc($result)) {
        $total=$row['balance'];
    }
}

$query_luckynumber = "SELECT `lucky_number` FROM `draws` ORDER BY `draws`.`date` DESC LIMIT 1;";
$result_luckynumber = $conn->query($query_luckynumber);

// Check if there is any data returned from the query
if ($result_luckynumber && $result_luckynumber->num_rows > 0) {
    // Fetch the lucky number
    $luckyNumber = $result_luckynumber->fetch_assoc()['lucky_number'];
} else {
    // If no data, generate a random number between 0 and 9
    $luckyNumber = rand(0, 9);
}
$draw_last_id_query = "SELECT `draw_id` FROM `draws` ORDER BY `draw_id` DESC LIMIT 1;";
$draw_id = ($conn->query($draw_last_id_query)->fetch_assoc()['draw_id'] ?? 'No draw_id found.') ?? 'No draw_id found.';
$query = "SELECT SUM(`amount_placed`*3.5) AS you_won FROM `betting` WHERE `draw_id` = '$draw_id' AND `status` = 'process' AND `winloss` = 'Goldwin' AND `user_id` = $user_id";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $you_won = $row['you_won'];

    if ($you_won > 0) {
        $notifications = array(
            array(
                'title' => 'Congratulation You won!!',
                'message' => 'Kes ' . number_format($you_won, 2),
                'class' => 'text-success'
            )
        );
    } else {
        $notifications = array();
    }
    $additionalNotifications = array(
        array(
            'title' => 'New Promotion',
            'message' => 'Get Kes 100 free on your first withdraw',
            'class' => 'text-primary'
        ),
        array(
            'title' => 'Jackpot Alert',
            'message' => 'You can now place bet as many time as possible',
            'class' => 'text-info'
        )
    );

    $notifications = array_merge($notifications, $additionalNotifications);
    $notifications = array_slice($notifications, 0, 3); // Limit to 3 notifications
} else {
    $notifications = array();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Lucky bet</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="favicon1.ico" rel="icon">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/font-awesome-animation@1.1.0/dist/font-awesome-animation.min.css">

    <!-- Libraries Stylesheet -->
    <link href="../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
    <style>
        .custom-alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 300px;
            padding: 20px;
            background-color: #f9f9f9;
            border: 2px solid #4caf50;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            z-index: 1000;
        }

        .custom-alert-content {
            position: relative;
        }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            cursor: pointer;
        }

        .check-icon {
            font-size: 50px;
            color: #4caf50;
        }

        .custom-alert p {
            margin: 20px 0;
            font-size: 18px;
        }

        .done-btn {
            padding: 10px 20px;
            background-color: #4caf50;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .done-btn:hover {
            background-color: #45a049;
        }
    </style>


</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner"
            class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sidebar Start -->
        <div class="sidebar pe-4 pb-3">
            <nav class="navbar bg-light navbar-light">
                <a href="index.php" class="navbar-brand mx-4 mb-3">
                    <h3 class="text-primary"><i class="fa fa-trophy me-2"></i>Lucky Bet</h3>
                </a>
                <div class="d-flex align-items-center ms-4 mb-4">
                    <div class="position-relative">
                        <img class="rounded-circle" src="../img/person1.avif" alt="" style="width: 40px; height: 40px;">
                        <div
                            class="bg-success rounded-circle border border-2 border-white position-absolute end-0 bottom-0 p-1">
                        </div>
                    </div>
                    <div class="ms-3">
                        <h6 class="mb-0" style="text-transform: capitalize;">
                            <?php echo $first_name." ". $last_name ?>
                        </h6>
                        <span>User</span>
                    </div>
                </div>
                <div class="navbar-nav w-100">
                    <a href="index.php" class="nav-item nav-link active "><i
                            class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
                    <a href="profile.php" class="nav-item nav-link "><i class="fa fa-user me-2"></i>Profile </a>
                    <a href="finance.php" class="nav-item nav-link "><i class="fa fa-wallet me-2"></i>Finance </a>
                    <a href="win.php" class="nav-item nav-link "><i class="fa fa-trophy me-2"></i>Winners </a>
                    <a href="step.php" class="nav-item nav-link "><i class="fa fa-tasks me-2"></i>How To Play</a>
                </div>
            </nav>
        </div>
        <!-- Sidebar End -->




        <!-- Content Start -->
        <div class="content">
            <!-- Navbar Start -->
            <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
                <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
                    <h2 class="text-primary mb-0"><i class="fa fa-trophy"></i></h2>
                </a>
                <a href="#" class="sidebar-toggler flex-shrink-0">
                    <i class="fa fa-bars"></i>
                </a>


                <div class="navbar-nav align-items-center ms-auto">

                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="fa fa-bell me-lg-2"></i>
                            <span class="d-none d-lg-inline-flex">Notification</span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-white border-0 rounded-0 rounded-bottom m-0">
                            <?php if (!empty($notifications)) : ?>
                            <?php foreach ($notifications as $notification) : ?>
                            <a href="#" class="dropdown-item">
                                <h6 class="fw-normal <?php echo $notification['class']; ?> mb-0">
                                    <?php echo $notification['title']; ?>
                                </h6>
                                <small class="<?php echo $notification['class']; ?>">
                                    <?php echo $notification['message']; ?>
                                </small>
                            </a>
                            <hr class="dropdown-divider">
                            <?php endforeach; ?>
                            <?php else : ?>
                            <a href="#" class="dropdown-item text-center">No notifications</a>
                            <?php endif; ?>
                            <a href="#" class="dropdown-item text-center">See all notifications</a>
                        </div>
                    </div>

                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                            <img class="rounded-circle me-lg-2" src="../img/person1.avif" alt=""
                                style="width: 40px; height: 40px;">
                            <span class="d-none d-lg-inline-flex" style="text-transform: capitalize;">
                                <?php echo $first_name." ". $last_name ?>
                            </span>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end bg-white border-0 rounded-0 rounded-bottom m-0">
                            <a href="logout.php" class="dropdown-item">Log Out</a>
                        </div>
                    </div>
                </div>
            </nav>
            <!-- Navbar End -->

            <!-- Sale & Revenue Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-4 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-start p-4">
                            <i class="fa fa-file-invoice-dollar fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Account Balance</p>
                                <h6 class="mb-0">Kes
                                    <?php echo $total ?>
                                </h6>
                            </div>
                        </div>
                    </div>

                    <div class="col-sm-4 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-start p-4">
                            <i class="fa fa-solid fa-crown fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Past Hour Fortune </p>
                                <h6 class="mb-0">
                                    <?php echo $luckyNumber ?>
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-start  p-4">
                            <i class="fa fa-clock fa-3x text-primary"></i>
                            <div class="ms-3">
                                <p class="mb-2">Next Draw In</p>
                                <h6 class="mb-0" id="timeRemainings">Loading.... </h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Sale & Revenue End -->

            <!-- Form Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-8">
                        <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
                            <!-- Indicators -->
                            <div class="carousel-indicators">
                                <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"
                                    aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1"
                                    aria-label="Slide 2"></button>
                                 <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2"
                                    aria-label="Slide 3"></button>
                                <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="3"
                                    aria-label="Slide 4"></button>

                            </div>

                            <!-- Slides -->
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="../img/poster3.jpg" class="d-block w-100" alt="Slide 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="../img/poster5.jpg" class="d-block w-100" alt="Slide 2">
                                </div>
                                <div class="carousel-item">
                                    <img src="../img/poster3.jpg" class="d-block w-100" alt="Slide 3">
                                </div>
                                <div class="carousel-item">
                                    <img src="../img/poster4.jpg" class="d-block w-100" alt="Slide 4">
                                </div>


                            </div>

                            <!-- Controls -->
                            <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel"
                                data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Previous</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#myCarousel"
                                data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Next</span>
                            </button>
                        </div>
                    </div>


                    <div class="col-sm-12 col-xl-4">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Play Now</h6>
                            <form method="POST" onsubmit="return validatebet() && validatelength()"
                                action="../php/bet_insert.php">
                                <div class="row mb-3">
                                    <label for="inputEmail3" class="col-sm-8 col-form-label"> Enter your
                                        lucknumber</label>
                                    <div class="col-sm-4">
                                        <input type="number" class="form-control" name="lucknumber" id="lucknumber"
                                            required>
                                    </div>
                                </div>
                                <div class="row mb-3">
                                    <label for="inputPassword3" class="col-sm-6 col-form-label">Amount</label>
                                    <div class="col-sm-6">
                                        <input type="number" class="form-control" id="amount" name="amount" required>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Place Bet</button>
                                <button type="submit" class="btn btn-secondary">Cancel</button>

                                <div class="row mb-3 bg-secondary mt-4"> <!-- Added mt-3 for margin-top -->
                                    <h2 class="col-sm-12 col-form-label text-white faa-pulse animated">
                                        <!-- Added faa-pulse animated for Font Awesome Animation -->
                                        Tip!
                                    </h2>
                                    <h3 class="col-sm-12 col-form-label text-white faa-pulse animated">
                                        <!-- Added faa-pulse animated for Font Awesome Animation -->
                                        Lucky Number range from 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
                                    </h3>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
            <!-- Form End -->

            <!--ad start
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-4 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-start  p-4">
                            <script type="text/javascript">
                                atOptions = {
                                    'key': '7962ffd38aa8c5ee97c5ce9a91301ddd',
                                    'format': 'iframe',
                                    'height': 250,
                                    'width': 300,
                                    'params': {}
                                };
                            </script>
                            <script type="text/javascript"
                                src="//www.topcreativeformat.com/7962ffd38aa8c5ee97c5ce9a91301ddd/invoke.js"></script>

                        </div>

                    </div>
                    <div class="col-sm-4 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-start  p-4">
                            <script type="text/javascript">
                                atOptions = {
                                    'key': '7962ffd38aa8c5ee97c5ce9a91301ddd',
                                    'format': 'iframe',
                                    'height': 250,
                                    'width': 300,
                                    'params': {}
                                };
                            </script>
                            <script type="text/javascript"
                                src="//www.topcreativeformat.com/7962ffd38aa8c5ee97c5ce9a91301ddd/invoke.js"></script>

                        </div>
                    </div>
                    <div class="col-sm-4 col-xl-4">
                        <div class="bg-light rounded d-flex align-items-center justify-content-start  p-4">
                            <script type="text/javascript">
                                atOptions = {
                                    'key': '7962ffd38aa8c5ee97c5ce9a91301ddd',
                                    'format': 'iframe',
                                    'height': 250,
                                    'width': 300,
                                    'params': {}
                                };
                            </script>
                            <script type="text/javascript"
                                src="//www.topcreativeformat.com/7962ffd38aa8c5ee97c5ce9a91301ddd/invoke.js"></script>

                        </div>
                    </div>



                </div>
            </div>


            ad end-->

            <!-- Recent Sales Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light text-center rounded p-4">
                    <div class="d-flex align-items-center justify-content-between mb-4">
                        <h6 class="mb-0">Recent Bet</h6>
                        <a href="">Show All</a>
                    </div>
                    <div class="table-responsive">
                        <?php
// Include the database connection file
include 'conn.php';

// Prepare the SQL query
$sql = "SELECT `betting_id`, `luck_number`, `amount_placed`, `time`, `status` FROM `betting` WHERE `user_id`=$user_id and status='pending ' ORDER BY `betting`.`time` DESC LIMIT 10;";

// Execute the query
$result = $conn->query($sql);

// Check if the query was successful
if ($result->num_rows > 0) {
    // Start building the table
    echo '<table class="table text-start align-middle table-bordered table-hover mb-0">';
    echo '<thead>
            <tr class="text-dark">
                
                <th scope="col">Betting Id</th>
                <th scope="col">Luck Number</th>
                <th scope="col">Amount Placed</th>
                <th scope="col">Time</th>
                <th scope="col">Status</th>
                
            </tr>
          </thead>
          <tbody>';

    // Loop through the results and populate the table rows
    while ($row = $result->fetch_assoc()) {
        echo '<tr>
                
                <td>' . $row["betting_id"] . '</td>
                <td>' . $row["luck_number"] . '</td>
                <td>' . $row["amount_placed"] . '</td>
                <td>' . $row["time"] . '</td>
                <td>' . $row["status"] . '</td>
                
            </tr>';
    }

    echo '</tbody></table>';
} else {
    echo "You have not place bet.";
}



?>
                    </div>
                </div>
            </div>
            <!-- Recent Sales End -->
             

            <div class="container-fluid pt-4 px-4">
                <div class="row g-4">
                    <div class="col-sm-6 col-xl-6">
                        
                    </div>
                    <div class="col-sm-6 col-xl-6">

                    </div>
                </div>
            </div>
             
            <?php
$rows_per_page = 10;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $rows_per_page;
$sql = "SELECT `draw_id`, `lucky_number`, `old_even`, `big_small`, `date` FROM `draws` ORDER BY `draws`.`draw_id` DESC LIMIT $rows_per_page OFFSET $offset ";
$result = $conn->query($sql);
$total_rows_sql = "SELECT COUNT(*) AS total FROM `draws`";
$total_rows_result = $conn->query($total_rows_sql);
$total_rows = $total_rows_result->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $rows_per_page);
?>
<div class="col-12">
    <div class="bg-light rounded h-100 p-4">
        <h6 class="mb-4">Draws</h6>
        <div class="table-responsive">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        <th scope="col">Draw ID</th>
                        <th scope="col">Lucky Number</th>
                        <th scope="col">Old/Even</th>
                        <th scope="col">Big/Small</th>
                        <th scope="col">Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $row['draw_id'] . "</td>";
                            echo "<td>" . $row['lucky_number'] . "</td>";
                            echo "<td>" . $row['old_even'] . "</td>";
                            echo "<td>" . $row['big_small'] . "</td>";
                            echo "<td>" . $row['date'] . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No results found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <nav aria-label="Page navigation">
            <ul class="pagination justify-content-center">
                <?php
                if ($page > 1) {
                    echo '<li class="page-item"><a class="page-link" href="?page=' . ($page - 1) . '">Previous</a></li>';
                }
                for ($i = 1; $i <= $total_pages; $i++) {
                    $active_class = ($i == $page) ? 'active' : '';
                    echo '<li class="page-item ' . $active_class . '"><a class="page-link" href="?page=' . $i . '">' . $i . '</a></li>';
                }
                if ($page < $total_pages) {
                    echo '<li class="page-item"><a class="page-link" href="?page=' . ($page + 1) . '">Next</a></li>';
                }
                ?>
            </ul>
        </nav>
    </div>
</div>


                  




            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#">Lucky Bet</a>, All Right Reserved.
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By <a href="#">Francis Njoroge</a>
                            </br>
                            Distributed By <a class="border-bottom" href="#" target="_blank">Amohtech</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <script>
        function validatebet() {
    var placebet = parseFloat(document.getElementById("amount").value);
    var userAccountBalance = <?php echo "$amount";?>;
    if (placebet < 10) {
        alert("Amount placed should be more than 10");
        return false;
    } else if (placebet > userAccountBalance) {
        alert("Insufficient funds. Your balance is Kes " + userAccountBalance + ".");
        return false;
    }
    return true;
}

function validatelength() {
    var lucknumber = document.getElementById("lucknumber").value;
    if (lucknumber.length > 1) {
        alert("Please enter one digit as Lucky Number");
        return false;
    }
    return true;
}

function showSuccessAlert() {
    // Create a custom alert or modal
    var customAlert = document.createElement('div');
    customAlert.className = 'custom-alert';
    customAlert.innerHTML = `
        <div class="custom-alert-content">
            <span class="close-btn">&times;</span>
            <div class="check-icon">&#10004;</div>
            <p>You have successfully placed your bet.</p>
            <button class="done-btn">Done</button>
        </div> `;

    // Add the custom alert to the document body
    document.body.appendChild(customAlert);

    // Add event listeners for closing the alert
    var closeBtn = customAlert.querySelector('.close-btn');
    var doneBtn = customAlert.querySelector('.done-btn');
    closeBtn.addEventListener('click', function () {
        window.location.reload();
        customAlert.remove();
    });
    doneBtn.addEventListener('click', function () {
        window.location.reload();
        customAlert.remove();
    });
}

// Add an event listener to the bet form submission
document.querySelector('form').addEventListener('submit', function (event) {
    event.preventDefault(); // Prevent the default form submission

    // Validate the bet amount and lucky number length
    var isBetValid = validatebet();
    var isLengthValid = validatelength();

    if (isBetValid && isLengthValid) {
        // Send an AJAX request to the server
        var formData = new FormData(this);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', '../php/bet_insert.php', true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.status === 'success') {
                        showSuccessAlert(); // Display the success alert
                    } else {
                        // Handle the error case
                        console.error('Error placing the bet');
                    }
                } else {
                    // Handle the error case
                    console.error('Error placing the bet');
                }
            }
        };
        xhr.send(formData);
    }
});

    </script>



    


    <script>
        // Connect to the database and fetch the data
        <?php
        require_once 'conn.php';

        $sql = "SELECT * FROM `draws` ORDER BY `draws`.`date` DESC LIMIT 5";
        $result = $conn -> query($sql);

        $data = array();
        while ($row = $result -> fetch_assoc()) {
            $data[] = $row;
        }
        ?>

        // Prepare the data for Chart.js
        var labels = [];
        var luckyNumbers = [];

        <?php foreach($data as $row): ?>
            labels.push('<?php echo $row['draw_id']; ?>');
        luckyNumbers.push(<?php echo $row['lucky_number']; ?>);
        <?php endforeach; ?>

        var ctx = document.getElementById('luckyNumberChart').getContext('2d');
        var luckyNumberChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Lucky Number',
                        data: luckyNumbers,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1,
                        pointRadius: 5,
                        pointBackgroundColor: function (context) {
                            var index = context.dataIndex;
                            return (luckyNumbers[index] % 2 === 0) ? 'green' : 'red';
                        }
                    }
                ]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>

    <script>
        function calculateRemainingTime() {
            var currentTime = new Date();
            var currentMinutes = currentTime.getMinutes();
            var currentSeconds = currentTime.getSeconds();
            var remainingMinutes = currentMinutes % 10; // Remaining minutes until the next 10-minute interval
            var remainingSeconds = currentSeconds; // Remaining seconds until the next minute
            var remainingTime = (10 - remainingMinutes - 1).toString().padStart(2, '0') + ':' + (60 - remainingSeconds).toString().padStart(2, '0');
            document.getElementById('timeRemainings').innerText = remainingTime;
        }
        setInterval(calculateRemainingTime, 1000);
    </script>




    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../lib/chart/chart.min.js"></script>
    <script src="../lib/easing/easing.min.js"></script>
    <script src="../lib/waypoints/waypoints.min.js"></script>
    <script src="../lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../lib/tempusdominus/js/moment.min.js"></script>
    <script src="../lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../js/main.js"></script>
</body>

</html>