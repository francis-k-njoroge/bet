<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Lucky bet</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="favicon1.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
        .navbar-brand {
          font-weight: bold;
        }
        /* Centering the navbar */
        .navbar-nav {
          margin: auto;
        }
        /* Making the navbar a bit bigger */
        .navbar {
          padding: 20px; /* Adjust the padding as needed */
        }
        /* Making nav items bold and adding hover effect */
        .nav-item {
          font-weight: bold;
        }
        .nav-link {
          transition: color 0.3s;
        }
        .nav-link:hover {
          background-color: black;
          color:white; 
        }
        /* Aligning buttons vertically on small screens */
        @media (max-width: 576px) {
          .navbar-collapse .d-flex {
            flex-direction: column;
          }
        }
       
      </style>

</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        


        <!-- Content Start -->
        <div class="container-fluid pt-0 px-0">
            <nav class="navbar navbar-expand-lg navbar-light bg-primary sticky-top">
                <div class="container">
                  <a class="navbar-brand text-white" href="#">Lucky Win</a>
                  <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                      <li class="nav-item">
                        <a class="nav-link text-white active" href="#">Home</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link text-white" href="#">About us</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link text-white" href="#">Testimonial</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link text-white" href="#">Contact us</a>
                      </li>
                    </ul>
                    <div class="d-flex">
                        <a href="register/signup.php"  class="btn btn-outline-info text-white me-2">Register</a>
                        <a href="register" class="btn btn-outline-dark text-white">Login</a>
                    </div>
                  </div>
                </div>
              </nav>

              <div class="container-fluid pt-0 px-0 my-5 text-center bg-light ">
                <h1 class="mb-4">Welcome, Winner!</h1>
                <h2 class="mb-4 display-4">WE TURN YOUR OPINION INTO MONEY</h2>
                <p class="mb-4 lead">Predict any number from 0 to 9, and you could be the next winner!</p>
                <p class="mb-4">Register now and transform your guesses into real money.</p>
                <div class="mb-4">
                  <a href="#" class="btn btn-primary me-2"><i class="bi bi-facebook"></i></a>
                  <a href="#" class="btn btn-primary me-2"><i class="bi bi-twitter"></i></a>
                  <a href="#" class="btn btn-primary me-2"><i class="bi bi-linkedin"></i></a>
                  <a href="#" class="btn btn-primary"><i class="bi bi-instagram"></i></a>
                </div>
                <div>
                    <a href="register" class="btn btn-primary me-3">Get started</a>
                  
                </div>
              </div>


              <div class="container-fluid pt-4 px-4">
                <h6 class="mb-4">How To Get started</h6>
                <div class="row g-4">
                    <div class="col-sm-12 col-xl-6">
                      <div class="bg-light">
                        <img src="img/dashboard.png" alt="" class="img-fluid" >
                        <img src="img/dashboard2.png" alt="" class="img-fluid" >
                        </div>
                    </div>
                    <div class="col-sm-12 col-xl-6">
                        <div class="bg-light rounded h-100 p-4">
                            <h6 class="mb-4">Steps to Get Started</h6>
                            <p><strong>STEP 1: Register</strong></p>
                            <p>Click on the "Sign Up" button. Fill in your details including username, first name, last name, email, phone number, and password. Click "Register" to create your account.</p>
                            <p><strong>STEP 2: Login</strong></p>
                            <p>Enter your username and password. Click on the "Login" button to access your account.</p>
                            <p><strong>STEP 3: Welcome to Your Account</strong></p>
                            <p>After logging in, you'll be welcomed to your account dashboard. Deposit money via M-Pesa. Purchase game credits by buying goods with code 5557772. Enter the code received after a successful deposit.</p>
                            <p><strong>STEP 4: Place Your Bet</strong></p>
                            <p>Choose your preferred game (e.g., select a lucky number or choose odd/even or big/small). Enter the amount you want to bet. Click "Submit" to place your bet.</p>
                            <p><strong>FINISH</strong></p>
                            <p>Sit back and relax! Wait for the draw to be conducted. Winners will be announced after the draw.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="bg-light rounded-top p-4">
                    <div class="row">
                        <div class="col-12 col-sm-6 text-center text-sm-start">
                            &copy; <a href="#">Lucky Bet</a>, All Right Reserved.
                        </div>
                        <div class="col-12 col-sm-6 text-center text-sm-end">
                            <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                            Designed By <a href="#">Francis Njoroge</a>
                            </br>
                            Distributed By <a class="border-bottom" href="#" target="_blank">Amohtech</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>



    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/chart/chart.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>