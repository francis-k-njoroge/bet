<?php  
ob_start(); 
require_once '..\welcome.php';
ob_end_clean();
$amount= $amount;
$phone_number=$phone_number;
$total= $total;
$user_id = $user_id;
?>

<?php
include '..\conn.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $user_id = $user_id; // Replace $user_id with the actual user ID
    $amount = $_POST["amount"];
    $phone_number = $_POST["phone_number"];
    $deposit_code = "LKWDU" . rand(10000, 99999) . "PRX";
    $date_of_deposit = date("Y-m-d");
    
    // Start a transaction
    $conn->begin_transaction();

    // Insert deposit record
    $deposit_sql = "INSERT INTO `deposit`(`user_id`, `amount`, `deposit_code`, `date_of_deposit`, `phone_number`) 
                    VALUES ($user_id, $amount, '$deposit_code', '$date_of_deposit', '$phone_number')";

    if ($conn->query($deposit_sql) === TRUE) {
        // Update amount balance in accounts table
        $update_sql = "UPDATE `accounts` SET `amount` = `amount` + $amount WHERE `user_id` = $user_id";
        if ($conn->query($update_sql) === TRUE) {
            // Commit the transaction if both queries are successful
            $conn->commit();
            header("Location: ../finance.php");
              
                 exit();
        } else {
            // Rollback the transaction if update query fails
            $conn->rollback();
            echo "Error updating amount balance: " . $conn->error;
        }
    } else {
        // Rollback the transaction if deposit query fails
        $conn->rollback();
        echo "Error inserting deposit record: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>

