<?php
ob_start();
require_once '../home/index.php';
ob_end_clean();
$user_id = $user_id;
$amount = $amount;

include '../home/conn.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $luckNumber = $_POST['lucknumber'];
    $amount = $_POST['amount'];
    $user_id = $user_id;
    
    $draw_id_query = "SELECT CONCAT('DR', LPAD(SUBSTRING(draw_id, 3) + 1, 5, '0')) AS new_draw_id FROM draws ORDER BY draw_id DESC LIMIT 1";
    $new_draw_id = $conn->query($draw_id_query)->fetch_assoc()['new_draw_id'] ?? 'DR00001';
    // Insert into betting table
    $sql = "INSERT INTO `betting` (`user_id`, `luck_number`, `amount_placed`, `time`, `status`,`draw_id`) VALUES ('$user_id', '$luckNumber', '$amount', NOW(), 'pending' ,'$new_draw_id')";
    if ($conn->query($sql) === TRUE) {
        // Update amount in accounts table
        $sql_get_amount = "SELECT `amount` FROM `accounts` WHERE `user_id` = '$user_id'";
        $result = $conn->query($sql_get_amount);
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $current_amount = $row['amount'];
            $new_amount = $current_amount - $amount;
            $sql_update_amount = "UPDATE `accounts` SET `amount`='$new_amount' WHERE `user_id`='$user_id'";
            if ($conn->query($sql_update_amount) === TRUE) {
                // Send a JSON response indicating success
                $response = array(
                    'status' => 'success'
                );
                echo json_encode($response);
                exit;
            } else {
                echo "Error updating amount: " . $conn->error;
            }
        } else {
            echo "Error: User not found";
        }
    } else {
        echo "Error placing bet: " . $conn->error;
    }
}
?>

