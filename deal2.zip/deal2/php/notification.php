<?php
include '../home/conn.php';
ob_start();
require_once '../home/index.php';
ob_end_clean(); 
$user_id=$user_id;
// Use $luckyNumber for further processing
$draw_last_id_query = "SELECT `draw_id` FROM `draws` ORDER BY `draw_id` DESC LIMIT 1;";
$draw_id = ($conn->query($draw_last_id_query)->fetch_assoc()['draw_id'] ?? 'No draw_id found.') ?? 'No draw_id found.';
$query = "SELECT SUM(`amount_placed`*3.5) AS you_won FROM `betting` WHERE `draw_id` = '$draw_id' AND `status` = 'process' AND `winloss` = 'Goldwin' AND `user_id` = $user_id";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $you_won = $row['you_won'];

    if ($you_won > 0) {
        $notifications = array(
            array(
                'title' => 'Congratulation You won!!',
                'message' => 'Kes ' . number_format($you_won, 2),
                'class' => 'text-success'
            )
        );
    } else {
        $notifications = array();
    }
    $additionalNotifications = array(
        array(
            'title' => 'New Promotion',
            'message' => 'Get Kes 100 free on your first withdraw',
            'class' => 'text-primary'
        ),
        array(
            'title' => 'Jackpot Alert',
            'message' => 'You can now place bet as many time as possible',
            'class' => 'text-info'
        )
    );

    $notifications = array_merge($notifications, $additionalNotifications);
    $notifications = array_slice($notifications, 0, 3); // Limit to 3 notifications
} else {
    $notifications = array();
}
?>