<?php
ob_start(); 
require_once '../welcome.php'; 
ob_end_clean(); 
$user_id = $user_id;
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $user_id = $user_id; // Replace $user_id with the actual user ID
    $amount = $_POST["amount"];
    $phone_number = $_POST["phone_number"];

//INCLUDE THE ACCESS TOKEN FILE
include 'accessToken.php';
date_default_timezone_set('Africa/Nairobi');
$processrequestUrl = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';
$callbackurl = 'https://a6a5-2c0f-6300-214-fa00-24c7-21fe-63d1-b7c5.ngrok-free.app/daraja/callback.php';
$passkey = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";
$BusinessShortCode = '174379';
$Timestamp = date('YmdHis');
// ENCRIPT  DATA TO GET PASSWORD
$Password = base64_encode($BusinessShortCode . $passkey . $Timestamp);
$phone = $phone_number;//phone number to receive the stk push
$money = '1';
$PartyA = $phone;
$PartyB = '254110229641';
$AccountReference = 'Francis k Njoroge';
$TransactionDesc = 'stkpush test';
$Amount = $money;
$stkpushheader = ['Content-Type:application/json', 'Authorization:Bearer ' . $access_token];
//INITIATE CURL
$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $processrequestUrl);
curl_setopt($curl, CURLOPT_HTTPHEADER, $stkpushheader); //setting custom header
$curl_post_data = array(
  //Fill in the request parameters with valid values
  'BusinessShortCode' => $BusinessShortCode,
  'Password' => $Password,
  'Timestamp' => $Timestamp,
  'TransactionType' => 'CustomerPayBillOnline',
  'Amount' => $Amount,
  'PartyA' => $PartyA,
  'PartyB' => $BusinessShortCode,
  'PhoneNumber' => $PartyA,
  'CallBackURL' => $callbackurl,
  'AccountReference' => $AccountReference,
  'TransactionDesc' => $TransactionDesc
);

$data_string = json_encode($curl_post_data);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
echo $curl_response = curl_exec($curl);
//ECHO  RESPONSE
$data = json_decode($curl_response);
$CheckoutRequestID = $data->CheckoutRequestID;
$ResponseCode = $data->ResponseCode;
if ($ResponseCode == "0") 
{
    include '../conn.php';

    $deposit_code = "LKWDU" . rand(10000, 99999) . "PRX";
    $date_of_deposit = date("Y-m-d");

    $conn->begin_transaction();

    $deposit_sql = "INSERT INTO `deposit`(`user_id`, `amount`, `deposit_code`, `date_of_deposit`, `phone_number`) VALUES ($user_id, $amount, '$deposit_code', '$date_of_deposit', '$phone_number')";
    if ($conn->query($deposit_sql) === TRUE) {
        $update_sql = "UPDATE `accounts` SET `amount` = `amount` + $amount WHERE `user_id` = $user_id";
        if ($conn->query($update_sql) === TRUE) {
            $conn->commit();
            header("Location: ../finance.php");
            exit();
        } else {
            $conn->rollback();
            echo "Error updating amount balance: " . $conn->error;
        }
    } else {
        $conn->rollback();
        echo "Error inserting deposit record: " . $conn->error;
    }

    $conn->close();
}
else{
    echo "The CheckoutRequestID for this transaction is : " . $CheckoutRequestID;
}

}