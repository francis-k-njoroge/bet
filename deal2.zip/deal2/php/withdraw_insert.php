<?php  
ob_start(); 
require_once '..\welcome.php';  
ob_end_clean();
$amount= $amount;
$phone_number=$phone_number;
$total= $total;
$user_id = $user_id;
?>
<?php
include '..\conn.php';
$user_id = $user_id; // Assuming you have already retrieved this
$withdraw_code = "WTH" . rand(10000, 99999) . "DRW";
$phone_number = isset($_POST['phone_number1']) ? $_POST['phone_number1'] : '';
$amount = isset($_POST['amount1']) ? $_POST['amount1'] : '';
$sql = "INSERT INTO `withdraw`(`user_id`, `amount`, `withdraw_code`, `date_of_withdraw`, `phone_number`) 
        VALUES ('$user_id', '$amount', '$withdraw_code', NOW(), '$phone_number')";

if(mysqli_query($conn, $sql)) {
   
    $update_sql = "UPDATE `accounts` SET `amount` = `amount` - $amount WHERE `user_id` = $user_id";
    if(mysqli_query($conn, $update_sql)) {
        header("Location: ../finance.php");
              
        exit();
    } else {
        echo "Error updating account balance: " . mysqli_error($conn);
    }
} else {
    echo "Error submitting withdrawal request: " . mysqli_error($conn);
}
?>
